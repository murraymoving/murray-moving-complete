import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MessageCircle, Calendar, MapPin, Phone, Mail, User, Star } from 'lucide-react';

const MobilePreview = () => {
  const [currentScreen, setCurrentScreen] = useState('welcome');
  const [formData, setFormData] = useState({
    serviceType: '',
    pickupAddress: '',
    dropoffAddress: '',
    moveDate: '',
    homeSize: '',
    name: '',
    phone: '',
    email: ''
  });

  const screens = {
    welcome: {
      title: 'Murray Moving',
      component: <WelcomeScreen onNext={setCurrentScreen} />
    },
    services: {
      title: 'Select Service',
      component: <ServiceTypeScreen onNext={setCurrentScreen} formData={formData} setFormData={setFormData} />
    },
    addresses: {
      title: 'Pickup & Delivery',
      component: <AddressScreen onNext={setCurrentScreen} formData={formData} setFormData={setFormData} />
    },
    datetime: {
      title: 'Move Date & Details',
      component: <DateTimeScreen onNext={setCurrentScreen} formData={formData} setFormData={setFormData} />
    },
    contact: {
      title: 'Contact Information',
      component: <ContactScreen onNext={setCurrentScreen} formData={formData} setFormData={setFormData} />
    },
    review: {
      title: 'Review Quote Request',
      component: <ReviewScreen onNext={setCurrentScreen} formData={formData} />
    },
    dashboard: {
      title: 'My Moves',
      component: <CustomerDashboard onNext={setCurrentScreen} />
    },
    admin: {
      title: 'Admin Portal',
      component: <AdminPortal onNext={setCurrentScreen} />
    }
  };

  const currentScreenData = screens[currentScreen as keyof typeof screens];

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-md mx-auto">
        {/* Mobile Phone Frame */}
        <div className="bg-black rounded-3xl p-2 shadow-2xl">
          <div className="bg-white rounded-2xl overflow-hidden h-[800px] flex flex-col">
            {/* Status Bar */}
            <div className="bg-black text-white px-4 py-2 text-xs flex justify-between items-center">
              <span>9:41</span>
              <span>Murray Moving</span>
              <span>100%</span>
            </div>

            {/* Header */}
            <div className="bg-black text-white px-4 py-4 flex items-center justify-between">
              {currentScreen !== 'welcome' && (
                <button 
                  onClick={() => setCurrentScreen('welcome')}
                  className="text-white"
                >
                  <ArrowLeft size={24} />
                </button>
              )}
              <h1 className="text-lg font-bold text-center flex-1">
                {currentScreenData.title}
              </h1>
              <div className="w-6"></div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto">
              {currentScreenData.component}
            </div>
          </div>
        </div>

        {/* Screen Navigation */}
        <div className="mt-4 grid grid-cols-4 gap-2">
          {Object.keys(screens).map((screen) => (
            <Button
              key={screen}
              variant={currentScreen === screen ? "default" : "outline"}
              size="sm"
              onClick={() => setCurrentScreen(screen)}
              className="text-xs capitalize"
            >
              {screen}
            </Button>
          ))}
        </div>

        {/* React Native App Info */}
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h3 className="font-bold text-sm mb-2">🚀 Ready to Run the Real Mobile App</h3>
          <div className="text-xs text-gray-600 space-y-1">
            <p><code>cd apps/mobile</code></p>
            <p><code>npx expo start</code></p>
            <p>• Scan QR code with Expo Go app</p>
            <p>• Real React Native app with job management</p>
            <p>• Database ready, push notifications, production build config</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const WelcomeScreen = ({ onNext }: { onNext: (screen: string) => void }) => (
  <div className="p-6 h-full flex flex-col">
    <div className="text-center mb-8">
      <div className="w-24 h-24 bg-black rounded-full flex items-center justify-center mx-auto mb-4">
        <span className="text-white font-bold text-2xl">MM</span>
      </div>
      <h2 className="text-2xl font-bold text-gray-800 mb-2">Murray Moving</h2>
      <p className="text-gray-600">Professional moving services in Central NJ</p>
    </div>

    <div className="space-y-4 flex-1">
      <Card className="p-4 border-2 border-green-200">
        <h3 className="font-semibold text-lg mb-2">🚛 Full-Service Moving</h3>
        <p className="text-gray-600 text-sm mb-3">Complete residential & commercial moves</p>
        <Button 
          className="w-full bg-green-600 hover:bg-green-700"
          onClick={() => onNext('services')}
        >
          Get Moving Quote
        </Button>
      </Card>

      <Card className="p-4 border-2 border-orange-200">
        <h3 className="font-semibold text-lg mb-2">🚐 Cargo Van Services</h3>
        <p className="text-gray-600 text-sm mb-3">Junk removal, furniture transport</p>
        <Button 
          className="w-full bg-orange-600 hover:bg-orange-700"
          onClick={() => onNext('services')}
        >
          Get Van Quote
        </Button>
      </Card>
    </div>

    <div className="mt-auto space-y-2">
      <Button 
        variant="ghost" 
        className="w-full text-blue-600"
        onClick={() => onNext('dashboard')}
      >
        Track My Move
      </Button>
      <button 
        className="text-xs text-gray-500 w-full"
        onClick={() => onNext('admin')}
      >
        Admin Login
      </button>
    </div>
  </div>
);

const ServiceTypeScreen = ({ onNext, formData, setFormData }: any) => (
  <div className="p-6">
    <p className="text-gray-600 mb-6">What type of moving service do you need?</p>
    
    <div className="space-y-4">
      <Card 
        className={`p-4 cursor-pointer border-2 ${formData.serviceType === 'full-service' ? 'border-green-500 bg-green-50' : 'border-gray-200'}`}
        onClick={() => setFormData({...formData, serviceType: 'full-service'})}
      >
        <h3 className="font-semibold text-lg">🏠 Full-Service Moving</h3>
        <p className="text-gray-600 text-sm">Complete household or office move</p>
        <div className="mt-2 text-xs text-gray-500">
          • Professional crew • Packing services • Loading & unloading
        </div>
      </Card>

      <Card 
        className={`p-4 cursor-pointer border-2 ${formData.serviceType === 'van-service' ? 'border-orange-500 bg-orange-50' : 'border-gray-200'}`}
        onClick={() => setFormData({...formData, serviceType: 'van-service'})}
      >
        <h3 className="font-semibold text-lg">📦 Cargo Van Service</h3>
        <p className="text-gray-600 text-sm">Smaller moves and junk removal</p>
        <div className="mt-2 text-xs text-gray-500">
          • Furniture transport • Junk removal • Donation pickups
        </div>
      </Card>
    </div>

    <Button 
      className="w-full mt-8"
      disabled={!formData.serviceType}
      onClick={() => onNext('addresses')}
    >
      Continue
    </Button>
  </div>
);

const AddressScreen = ({ onNext, formData, setFormData }: any) => (
  <div className="p-6">
    <p className="text-gray-600 mb-6">Where are we moving from and to?</p>
    
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-2">Pickup Address</label>
        <Input
          placeholder="Enter pickup address"
          value={formData.pickupAddress}
          onChange={(e) => setFormData({...formData, pickupAddress: e.target.value})}
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Delivery Address</label>
        <Input
          placeholder="Enter delivery address"
          value={formData.dropoffAddress}
          onChange={(e) => setFormData({...formData, dropoffAddress: e.target.value})}
        />
      </div>

      <Card className="p-4 bg-blue-50">
        <h4 className="font-medium text-sm">📍 Service Area</h4>
        <p className="text-xs text-gray-600 mt-1">
          Within 100 miles of Chesterfield, NJ including all of Central Jersey
        </p>
      </Card>
    </div>

    <Button 
      className="w-full mt-8"
      disabled={!formData.pickupAddress || !formData.dropoffAddress}
      onClick={() => onNext('datetime')}
    >
      Continue
    </Button>
  </div>
);

const DateTimeScreen = ({ onNext, formData, setFormData }: any) => (
  <div className="p-6">
    <p className="text-gray-600 mb-6">Move details and property information</p>
    
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-2">Preferred Move Date</label>
        <Input
          type="date"
          value={formData.moveDate}
          onChange={(e) => setFormData({...formData, moveDate: e.target.value})}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium mb-2">Pickup Type</label>
          <select 
            className="w-full p-2 border rounded text-xs"
            value={formData.pickupType}
            onChange={(e) => setFormData({...formData, pickupType: e.target.value})}
          >
            <option value="">Select</option>
            <option value="house">House</option>
            <option value="apartment">Apartment</option>
            <option value="condo">Condo</option>
            <option value="office">Office</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Floor #</label>
          <Input
            type="number"
            placeholder="1"
            value={formData.pickupFloor}
            onChange={(e) => setFormData({...formData, pickupFloor: e.target.value})}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium mb-2">Stairs/Elevator</label>
          <select 
            className="w-full p-2 border rounded text-xs"
            value={formData.pickupStairs}
            onChange={(e) => setFormData({...formData, pickupStairs: e.target.value})}
          >
            <option value="">Select</option>
            <option value="stairs">Stairs</option>
            <option value="elevator">Elevator</option>
            <option value="na">N/A</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2"># of Stairs</label>
          <Input
            type="number"
            placeholder="0"
            value={formData.stairCount}
            onChange={(e) => setFormData({...formData, stairCount: e.target.value})}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Parking Situation</label>
        <select 
          className="w-full p-2 border rounded"
          value={formData.parking}
          onChange={(e) => setFormData({...formData, parking: e.target.value})}
        >
          <option value="">Select parking</option>
          <option value="driveway">Driveway</option>
          <option value="street">Street Parking</option>
          <option value="parking-lot">Parking Lot</option>
          <option value="loading-dock">Loading Dock</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Estimated # of Boxes</label>
        <Input
          type="number"
          placeholder="12"
          value={formData.estimatedBoxes}
          onChange={(e) => setFormData({...formData, estimatedBoxes: e.target.value})}
        />
      </div>

      <Card className="p-4 bg-yellow-50">
        <h4 className="font-medium text-sm">⚡ Emergency Options</h4>
        <p className="text-xs text-gray-600 mt-1">
          Same-day: +25% • Emergency: +50% • Weekends: +15%
        </p>
      </Card>
    </div>

    <Button 
      className="w-full mt-8"
      disabled={!formData.moveDate || !formData.pickupType}
      onClick={() => onNext('contact')}
    >
      Continue
    </Button>
  </div>
);

const ContactScreen = ({ onNext, formData, setFormData }: any) => (
  <div className="p-6">
    <p className="text-gray-600 mb-6">How can we reach you with your quote?</p>
    
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-2">Full Name</label>
        <Input
          placeholder="Your name"
          value={formData.name}
          onChange={(e) => setFormData({...formData, name: e.target.value})}
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Phone Number</label>
        <Input
          placeholder="(609) 724-4445"
          value={formData.phone}
          onChange={(e) => setFormData({...formData, phone: e.target.value})}
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Email Address</label>
        <Input
          type="email"
          placeholder="your@email.com"
          value={formData.email}
          onChange={(e) => setFormData({...formData, email: e.target.value})}
        />
      </div>
    </div>

    <Button 
      className="w-full mt-8"
      disabled={!formData.name || !formData.phone || !formData.email}
      onClick={() => onNext('review')}
    >
      Continue
    </Button>
  </div>
);

const ReviewScreen = ({ onNext, formData }: any) => (
  <div className="p-6">
    <p className="text-gray-600 mb-6">Please review your quote request</p>
    
    <div className="space-y-4">
      <Card className="p-4">
        <h4 className="font-medium mb-2">Service Details</h4>
        <p className="text-sm text-gray-600 capitalize">{formData.serviceType?.replace('-', ' ')}</p>
        <p className="text-sm text-gray-600">{formData.homeSize}</p>
      </Card>

      <Card className="p-4">
        <h4 className="font-medium mb-2">Addresses</h4>
        <p className="text-sm text-gray-600">From: {formData.pickupAddress}</p>
        <p className="text-sm text-gray-600">To: {formData.dropoffAddress}</p>
      </Card>

      <Card className="p-4">
        <h4 className="font-medium mb-2">Contact</h4>
        <p className="text-sm text-gray-600">{formData.name}</p>
        <p className="text-sm text-gray-600">{formData.phone}</p>
        <p className="text-sm text-gray-600">{formData.email}</p>
      </Card>

      <Card className="p-4 bg-green-50">
        <h4 className="font-medium mb-2">💰 Estimated Price Range</h4>
        <p className="text-lg font-bold text-green-600">$240 - $480</p>
        <p className="text-xs text-gray-600">Based on 2-4 hour job at $120/hour</p>
      </Card>
    </div>

    <Button 
      className="w-full mt-8 bg-green-600 hover:bg-green-700"
      onClick={() => onNext('dashboard')}
    >
      Submit Quote Request
    </Button>
  </div>
);

const CustomerDashboard = ({ onNext }: any) => (
  <div className="p-6">
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h4 className="font-medium">Recent Quote</h4>
          <Badge variant="secondary">Pending</Badge>
        </div>
        <p className="text-sm text-gray-600">Full-Service Moving</p>
        <p className="text-xs text-gray-500 mt-1">Submitted 2 hours ago</p>
        <Button size="sm" className="mt-2">View Details</Button>
      </Card>

      <Card className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h4 className="font-medium">Scheduled Move</h4>
          <Badge className="bg-green-100 text-green-800">Confirmed</Badge>
        </div>
        <p className="text-sm text-gray-600">Dec 15, 2024 at 9:00 AM</p>
        <p className="text-xs text-gray-500 mt-1">2-man crew assigned</p>
        <div className="flex gap-2 mt-2">
          <Button size="sm" variant="outline">
            <MessageCircle size={16} className="mr-1" />
            Message
          </Button>
          <Button size="sm" variant="outline">
            <MapPin size={16} className="mr-1" />
            Track
          </Button>
        </div>
      </Card>

      <Card className="p-4 bg-blue-50">
        <h4 className="font-medium mb-2">Need Help?</h4>
        <p className="text-sm text-gray-600 mb-3">Contact Murray Moving directly</p>
        <div className="space-y-2">
          <Button variant="outline" size="sm" className="w-full justify-start">
            <Phone size={16} className="mr-2" />
            (609) 724-4445
          </Button>
          <Button variant="outline" size="sm" className="w-full justify-start">
            <Mail size={16} className="mr-2" />
            info@murraymoving.com
          </Button>
        </div>
      </Card>
    </div>
  </div>
);

const AdminPortal = ({ onNext }: any) => (
  <div className="p-6">
    <div className="text-center mb-6">
      <h3 className="text-lg font-bold">Murray Moving Admin</h3>
      <p className="text-sm text-gray-600">Job Management System</p>
    </div>

    <div className="space-y-4">
      <Card className="p-4">
        <h4 className="font-medium mb-3">📋 New Quotes (3)</h4>
        <div className="space-y-3">
          <div className="border-b pb-2">
            <div className="flex justify-between items-start mb-1">
              <span className="font-medium text-sm">Quote #Q-001</span>
              <Button size="sm">Convert to Job</Button>
            </div>
            <p className="text-xs text-gray-600">John Smith - Full Service Move</p>
            <p className="text-xs text-gray-500">Hamilton NJ → Hopewell NJ</p>
            <p className="text-xs text-gray-500">Estimated: $600 • 2-man crew</p>
          </div>
          <div className="border-b pb-2">
            <div className="flex justify-between items-start mb-1">
              <span className="font-medium text-sm">Quote #Q-002</span>
              <Button size="sm" variant="outline">Review</Button>
            </div>
            <p className="text-xs text-gray-600">Mary Johnson - Van Service</p>
            <p className="text-xs text-gray-500">Princeton NJ → Local</p>
          </div>
        </div>
      </Card>

      <Card className="p-4">
        <h4 className="font-medium mb-3">🚛 Active Jobs</h4>
        <div className="space-y-3">
          <div className="border-b pb-2">
            <div className="flex justify-between items-start mb-1">
              <span className="font-medium text-sm">Job #001</span>
              <Badge className="bg-green-100 text-green-800">En Route</Badge>
            </div>
            <p className="text-xs text-gray-600">Ca$h (Crew Leader) • 2-man crew</p>
            <p className="text-xs text-gray-500">9:00 AM - Hamilton → Hopewell</p>
            <p className="text-xs text-gray-500">Invoice #001 • $600 quoted</p>
            <div className="mt-2 flex gap-1">
              <Button size="sm" variant="outline" className="text-xs px-2 py-1">Track</Button>
              <Button size="sm" variant="outline" className="text-xs px-2 py-1">Message</Button>
              <Button size="sm" variant="outline" className="text-xs px-2 py-1">Update</Button>
            </div>
          </div>
          <div className="border-b pb-2">
            <div className="flex justify-between items-start mb-1">
              <span className="font-medium text-sm">Job #002</span>
              <Badge variant="secondary">Scheduled</Badge>
            </div>
            <p className="text-xs text-gray-600">2:00 PM - Office Move</p>
            <p className="text-xs text-gray-500">Trenton → Princeton</p>
          </div>
        </div>
      </Card>

      <Card className="p-4">
        <h4 className="font-medium mb-3">📊 Today's Summary</h4>
        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <p className="text-lg font-bold text-green-600">5</p>
            <p className="text-xs text-gray-600">Jobs Scheduled</p>
          </div>
          <div>
            <p className="text-lg font-bold text-blue-600">$2,400</p>
            <p className="text-xs text-gray-600">Revenue Today</p>
          </div>
        </div>
      </Card>
    </div>
  </div>
);

export default MobilePreview;