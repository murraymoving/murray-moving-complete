import { Helmet } from "react-helmet-async";
import { Award, Users, Clock, Shield, Truck } from "lucide-react";

export default function About() {
  const values = [
    {
      icon: Award,
      title: "Excellence",
      description: "We strive for excellence in every move, treating your belongings with the utmost care and professionalism."
    },
    {
      icon: Users,
      title: "Customer Service",
      description: "Our customers are at the heart of everything we do. We're committed to exceeding your expectations."
    },
    {
      icon: Clock,
      title: "Reliability",
      description: "When we say we'll be there, we'll be there. On time, every time, with the service you deserve."
    },
    {
      icon: Shield,
      title: "Trust",
      description: "We understand you're trusting us with your most precious belongings. We don't take that responsibility lightly."
    }
  ];

  const teamMembers = [
    {
      name: "John Murray",
      role: "Founder & CEO",
      bio: "With over 15 years in the moving industry, John founded Murray Moving to provide exceptional service to families and businesses."
    },
    {
      name: "Sarah Johnson",
      role: "Operations Manager",
      bio: "Sarah ensures every move runs smoothly, coordinating our team of professional movers and customer service representatives."
    },
    {
      name: "Mike Rodriguez",
      role: "Lead Moving Specialist",
      bio: "Mike has been with Murray Moving since the beginning, training new movers and handling our most complex relocations."
    }
  ];

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>About Murray Moving - Cargo Van Services & Junk Removal Since 2015</title>
        <meta name="description" content="Learn about Murray Moving's cargo van services including junk removal, furniture transportation, small moves, and estate cleanouts in Chesterfield, NJ." />
        <meta name="keywords" content="about Murray Moving, cargo van services, junk removal, furniture transport, small moves, estate cleanouts, Chesterfield NJ" />
      </Helmet>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-green-600 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">About Murray Moving</h1>
            <p className="text-xl md:text-2xl text-green-100 max-w-3xl mx-auto">
              Your trusted cargo van service provider since 2022, specializing in junk removal, furniture transport, and small moves
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-lg text-gray-600 mb-6">
                Murray Moving was founded in 2022 with a simple mission: to provide reliable, professional cargo van services 
                that exceed our customers' expectations. What started as a small junk removal service has grown into a 
                comprehensive solution for all your small moving, cleanout, and transportation needs.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Over the years, we've built our reputation on three core principles: exceptional service, careful handling 
                of your belongings, and transparent, honest communication. Our cargo van is equipped to handle everything from 
                single furniture pieces to complete estate cleanouts.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Today, we're proud to have completed over 300 successful jobs, from junk removal and furniture transportation 
                to estate cleanouts and donation pickups. But what we're most proud of is helping our community members 
                during transitions and cleanouts with care and respect.
              </p>
              <div className="grid grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">300+</div>
                  <div className="text-gray-600">Successful Jobs</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">9+</div>
                  <div className="text-gray-600">Years Experience</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">100%</div>
                  <div className="text-gray-600">Customer Satisfaction</div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-8 rounded-lg shadow-lg">
              <div className="text-center">
                <div className="w-24 h-24 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Truck className="w-12 h-12 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Professional Service</h3>
                <p className="text-gray-600">
                  Every job we complete reinforces our commitment to quality service and customer satisfaction.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600">The principles that guide everything we do</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center bg-white rounded-lg p-8 shadow-lg">
                <div className="bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-murray-navy mb-4">Meet Our Team</h2>
            <p className="text-xl text-gray-600">The dedicated professionals who make your move possible</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="text-center bg-white rounded-lg p-6 shadow-lg">
                <div className="w-20 h-20 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{member.name}</h3>
                <p className="text-green-600 font-medium mb-3">{member.role}</p>
                <p className="text-gray-600">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-murray-navy mb-4">Why Choose Murray Moving?</h2>
            <p className="text-xl text-gray-600">What sets us apart from other moving companies</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-murray-navy mb-4">Licensed & Insured</h3>
              <p className="text-gray-600">
                We're fully licensed and insured, giving you peace of mind knowing your belongings are protected 
                throughout the entire moving process.
              </p>
            </div>
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-murray-navy mb-4">Trained Professionals</h3>
              <p className="text-gray-600">
                Our team undergoes comprehensive training and background checks to ensure they meet our high standards 
                for professionalism and reliability.
              </p>
            </div>
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-murray-navy mb-4">Transparent Pricing</h3>
              <p className="text-gray-600">
                No hidden fees or surprise charges. We provide detailed, upfront pricing so you know exactly what 
                to expect before we begin.
              </p>
            </div>
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-murray-navy mb-4">Customer-Focused</h3>
              <p className="text-gray-600">
                We tailor our services to meet your specific needs and timeline, providing personalized attention 
                to every customer and every move.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
