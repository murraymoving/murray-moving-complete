import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users, Briefcase, Calendar, DollarSign, TrendingUp, 
  Clock, CheckCircle, Circle, AlertCircle, MapPin, Phone, Lock, Download
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useEffect } from "react";
import { clientStorage } from "@/lib/clientStorage";
import { useQuery } from "@/lib/clientQueryClient";
import JobManagementClient from "@/components/job-management-client";
import CustomerManagementClient from "@/components/customer-management-client";
import { ExportManagerClient } from "@/components/export-manager-client";
import newLogoPath from "@assets/phonto 2_1752189305081.jpg";

// Declare global MURRAY_AUTH for TypeScript
declare global {
  interface Window {
    MURRAY_AUTH: {
      isAuthenticated: () => boolean;
      login: (username: string, password: string) => { success: boolean };
      logout: () => void;
    };
  }
}

export default function BusinessDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginData, setLoginData] = useState({ username: "", password: "" });

  // Force refresh trigger
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  
  // Dashboard stats - always call hooks
  const { data: dashboardStats, isLoading: statsLoading, refetch: refetchStats } = useQuery({
    queryKey: ["/api/dashboard/stats", refreshTrigger],
    refetchInterval: 5000, // Refresh every 5 seconds
    enabled: true, // Always run - no auth needed for testing
  });

  // Listen for localStorage changes to trigger refresh
  useEffect(() => {
    const handleStorageChange = () => {
      setRefreshTrigger(prev => prev + 1);
    };

    window.addEventListener('storage', handleStorageChange);
    // Also listen for manual refresh events
    window.addEventListener('murrayRefresh', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('murrayRefresh', handleStorageChange);
    };
  }, []);

  // Monthly financials
  const { data: financials, isLoading: financialsLoading } = useQuery({
    queryKey: ["/api/dashboard/financials"],
    refetchInterval: 60000, // Refresh every minute
    enabled: true, // Always run - no auth needed for testing
  });

  // Recent jobs for dashboard
  const { data: recentJobs } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: true, // Always run - no auth needed for testing
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'lead': return 'bg-gray-100 text-gray-800';
      case 'estimate': return 'bg-yellow-100 text-yellow-800';
      case 'booked': return 'bg-blue-100 text-blue-800';
      case 'active': return 'bg-orange-100 text-orange-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'paid': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'lead': return <Circle className="w-4 h-4" />;
      case 'estimate': return <Clock className="w-4 h-4" />;
      case 'booked': return <CheckCircle className="w-4 h-4" />;
      case 'active': return <AlertCircle className="w-4 h-4" />;
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'paid': return <DollarSign className="w-4 h-4" />;
      default: return <Circle className="w-4 h-4" />;
    }
  };

  // Check authentication on mount and initialize sample data
  useEffect(() => {
    if (window.MURRAY_AUTH && window.MURRAY_AUTH.isAuthenticated()) {
      setIsAuthenticated(true);
      // Initialize sample data if needed
      clientStorage.initializeSampleData();
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    
    try {
      if (window.MURRAY_AUTH) {
        const result = window.MURRAY_AUTH.login(loginData.username, loginData.password);
        if (result.success) {
          setIsAuthenticated(true);
          // Initialize sample data when user logs in
          clientStorage.initializeSampleData();
        } else {
          alert("Invalid credentials. Please try again.");
        }
      } else {
        alert("Authentication system not loaded. Please refresh the page.");
      }
    } catch (error) {
      console.error("Login error:", error);
      alert("Login failed. Please try again.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleExportData = () => {
    const data = clientStorage.exportData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { 
      type: 'application/json' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `murray-moving-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Show login form if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Custom Business Header */}
        <header className="bg-black text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-center h-16">
              {/* Logo */}
              <img 
                src={newLogoPath} 
                alt="Murray Moving Logo" 
                className="h-12 w-auto object-contain"
                style={{ 
                  maxWidth: '200px',
                  maxHeight: '48px'
                }}
              />
            </div>
          </div>
        </header>

        <div className="flex items-center justify-center p-6 mt-20">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center space-x-2">
                <Lock className="w-6 h-6 text-gray-600" />
                <span>Business Portal Login</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    type="text"
                    value={loginData.username}
                    onChange={(e) => setLoginData({...loginData, username: e.target.value})}
                    required
                    placeholder="Enter username"
                  />
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={loginData.password}
                    onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                    required
                    placeholder="Enter password"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoggingIn}>
                  {isLoggingIn ? "Logging in..." : "Login"}
                </Button>
              </form>
              
              <div className="mt-6 p-4 bg-gray-100 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">
                  <strong>Demo Credentials:</strong>
                </p>
                <p className="text-sm font-mono text-gray-800">
                  Username: <span className="font-semibold">Admin_mm</span><br/>
                  Password: <span className="font-semibold">Gnivom22Murray?</span>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Main dashboard layout with sticky header
  return (
    <div className="min-h-screen bg-background">
      {/* Custom Business Header - Always stays at top */}
      <header className="bg-black text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <img 
                src={newLogoPath} 
                alt="Murray Moving Logo" 
                className="h-10 w-auto object-contain"
                style={{ 
                  maxWidth: '180px',
                  maxHeight: '40px'
                }}
              />
            </div>
            
            {/* Action Buttons */}
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleExportData}
                className="bg-white text-black hover:bg-gray-100"
              >
                <Download className="w-4 h-4 mr-1" />
                Export Data
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  if (window.MURRAY_AUTH) {
                    window.MURRAY_AUTH.logout();
                    setIsAuthenticated(false);
                  }
                }}
                className="bg-white text-black hover:bg-gray-100"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Content Area */}
      <div className="max-w-7xl mx-auto p-3 sm:p-6 space-y-4 sm:space-y-6">
        
        {/* Navigation Tabs - Always visible */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-5 h-auto p-1">
            <TabsTrigger value="dashboard" className="text-xs sm:text-sm px-2 py-2">Dashboard</TabsTrigger>
            <TabsTrigger value="jobs" className="text-xs sm:text-sm px-2 py-2">Jobs</TabsTrigger>
            <TabsTrigger value="customers" className="text-xs sm:text-sm px-2 py-2">Customers</TabsTrigger>
            <TabsTrigger value="analytics" className="text-xs sm:text-sm px-2 py-2">Analytics</TabsTrigger>
            <TabsTrigger value="exports" className="text-xs sm:text-sm px-2 py-2">Export</TabsTrigger>
          </TabsList>

          {/* Dashboard Overview */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardStats?.totalCustomers || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    All time customers
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Jobs</CardTitle>
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardStats?.totalJobs || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {dashboardStats?.monthlyJobs || 0} this month
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
                  <AlertCircle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardStats?.activeJobs || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    Currently in progress
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Actual Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    ${(dashboardStats?.actualRevenue || 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    From completed/paid jobs
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Second row with additional metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Potential Revenue</CardTitle>
                  <TrendingUp className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">
                    ${(dashboardStats?.potentialRevenue || 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    From booked/estimate jobs
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Pipeline</CardTitle>
                  <DollarSign className="h-4 w-4 text-purple-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">
                    ${(dashboardStats?.totalRevenue || 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Actual + Potential revenue
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg Job Value</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ${(dashboardStats?.averageJobValue || 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Average per completed job
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">This Month</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ${(dashboardStats?.monthlyRevenue || 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    + ${(dashboardStats?.monthlyPotentialRevenue || 0).toLocaleString()} potential
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ${dashboardStats?.totalRevenue?.toLocaleString() || '0'}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    ${dashboardStats?.monthlyRevenue?.toLocaleString() || '0'} this month
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Jobs */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Jobs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentJobs?.slice(0, 5).map((job: any) => (
                    <div key={job.id} className="flex items-center justify-between border-b pb-2">
                      <div className="flex items-center space-x-3">
                        {getStatusIcon(job.status)}
                        <div>
                          <p className="font-medium">{job.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {job.originCity}, {job.originState} → {job.destinationCity}, {job.destinationState}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge className={getStatusColor(job.status)}>
                          {job.status}
                        </Badge>
                        {job.totalCost && (
                          <p className="text-sm font-medium mt-1">
                            ${job.totalCost.toLocaleString()}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                  {(!recentJobs || recentJobs.length === 0) && (
                    <p className="text-muted-foreground text-center py-4">
                      No jobs found. Create your first job to get started.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Job Management */}
          <TabsContent value="jobs">
            <JobManagementClient onBack={() => setActiveTab("dashboard")} />
          </TabsContent>

          {/* Customer Management */}
          <TabsContent value="customers">
            <CustomerManagementClient onBack={() => setActiveTab("dashboard")} />
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Business Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">
                      ${dashboardStats?.averageJobValue?.toFixed(0) || '0'}
                    </p>
                    <p className="text-sm text-muted-foreground">Average Job Value</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">
                      {dashboardStats?.completedJobs || 0}
                    </p>
                    <p className="text-sm text-muted-foreground">Completed Jobs</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-purple-600">
                      {((dashboardStats?.completedJobs || 0) / (dashboardStats?.totalJobs || 1) * 100).toFixed(1)}%
                    </p>
                    <p className="text-sm text-muted-foreground">Completion Rate</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Monthly Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {financials?.monthlyData?.map((month: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <p className="font-medium">{month.month}</p>
                        <p className="text-sm text-muted-foreground">{month.jobs} jobs</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-green-600">
                          ${month.revenue.toLocaleString()}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          ${(month.revenue - month.expenses).toLocaleString()} profit
                        </p>
                      </div>
                    </div>
                  )) || (
                    <p className="text-muted-foreground text-center py-4">
                      No financial data available yet.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Export Management */}
          <TabsContent value="exports">
            <ExportManagerClient />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}