import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users, Briefcase, Calendar, DollarSign, TrendingUp, 
  Clock, CheckCircle, Circle, AlertCircle, MapPin, Phone, Lock, Download
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useEffect } from "react";
import JobManagement from "@/components/job-management";
import CustomerManagement from "@/components/customer-management";
import { ExportManager } from "@/components/export-manager";
import { CustomizableDashboard } from "@/components/customizable-dashboard";

// Declare global MURRAY_AUTH for TypeScript
declare global {
  interface Window {
    MURRAY_AUTH: {
      isAuthenticated: () => boolean;
      login: (username: string, password: string) => { success: boolean };
      logout: () => void;
    };
  }
}

export default function BusinessDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginData, setLoginData] = useState({ username: "", password: "" });

  // Dashboard stats - always call hooks
  const { data: dashboardStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    refetchInterval: 30000, // Refresh every 30 seconds
    enabled: isAuthenticated, // Only run when authenticated
  });

  // Monthly financials
  const { data: financials, isLoading: financialsLoading } = useQuery({
    queryKey: ["/api/dashboard/financials"],
    refetchInterval: 60000, // Refresh every minute
    enabled: isAuthenticated,
  });

  // Recent jobs for dashboard
  const { data: recentJobs } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: isAuthenticated,
  });

  const getStatusColor = (status: string) => {
    const colors = {
      lead: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
      estimate: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
      booked: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      active: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
      completed: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
      paid: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200",
      canceled: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
    };
    return colors[status as keyof typeof colors] || "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
  };

  // Check if already authenticated on page load
  useEffect(() => {
    // Check client-side authentication for Murray Moving
    if (window.MURRAY_AUTH && window.MURRAY_AUTH.isAuthenticated()) {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    
    try {
      // Use client-side authentication for Murray Moving
      if (window.MURRAY_AUTH) {
        const result = window.MURRAY_AUTH.login(loginData.username, loginData.password);
        
        if (result.success) {
          setIsAuthenticated(true);
        } else {
          alert('Invalid credentials. Please check your username and password.');
        }
      } else {
        alert('Authentication system not available.');
      }
    } catch (error) {
      alert("Login failed");
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Show login form if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Custom Business Header */}
        <header className="bg-black text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-center h-16">
              {/* Logo */}
              <div className="text-xl sm:text-2xl font-bold tracking-tight">
                <span className="text-white">MURRAY</span>
                <span className="text-green-500 ml-1">MOVING</span>
              </div>
            </div>
          </div>
        </header>

        <div className="flex items-center justify-center p-6 mt-20">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center space-x-2">
                <Lock className="w-6 h-6 text-gray-600" />
                <span>Business Portal Login</span>
              </CardTitle>
            </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  value={loginData.username}
                  onChange={(e) => setLoginData({...loginData, username: e.target.value})}
                  required
                  placeholder="Enter username"
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={loginData.password}
                  onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                  required
                  placeholder="Enter password"
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoggingIn}>
                {isLoggingIn ? "Logging in..." : "Login"}
              </Button>
            </form>
          </CardContent>
        </Card>
        </div>
      </div>
    );
  }



  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'lead': return <Circle className="w-4 h-4" />;
      case 'estimate': return <Clock className="w-4 h-4" />;
      case 'booked': return <CheckCircle className="w-4 h-4" />;
      case 'active': return <AlertCircle className="w-4 h-4" />;
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'paid': return <DollarSign className="w-4 h-4" />;
      default: return <Circle className="w-4 h-4" />;
    }
  };

  if (activeTab === "jobs") {
    return <JobManagement onBack={() => setActiveTab("dashboard")} />;
  }

  if (activeTab === "customers") {
    return <CustomerManagement onBack={() => setActiveTab("dashboard")} />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Custom Business Header */}
      <header className="bg-black text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="text-xl sm:text-2xl font-bold tracking-tight">
                <span className="text-white">MURRAY</span>
                <span className="text-green-500 ml-1">MOVING</span>
              </div>
            </div>
            
            {/* Logout Button */}
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                if (window.MURRAY_AUTH) {
                  window.MURRAY_AUTH.logout();
                  setIsAuthenticated(false);
                }
              }}
              className="bg-white text-black hover:bg-gray-100"
            >
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-3 sm:p-6 space-y-4 sm:space-y-6">
        {/* Dashboard Header */}
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-3 sm:space-y-0">
          <div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-foreground">Business Dashboard</h1>
            <p className="text-sm sm:text-base text-muted-foreground mt-1">Job pipeline & analytics</p>
          </div>
          <div className="text-center sm:text-right">
            <p className="text-xs sm:text-sm text-muted-foreground">Updated: {new Date().toLocaleTimeString()}</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-1">
            <TabsTrigger value="dashboard" className="text-xs sm:text-sm">Overview</TabsTrigger>
            <TabsTrigger value="jobs" className="text-xs sm:text-sm">Jobs</TabsTrigger>
            <TabsTrigger value="customers" className="text-xs sm:text-sm">Customers</TabsTrigger>
            <TabsTrigger value="financials" className="text-xs sm:text-sm">Money</TabsTrigger>
            <TabsTrigger value="exports" className="text-xs sm:text-sm col-span-2 sm:col-span-1">Export</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <CustomizableDashboard 
              isAuthenticated={isAuthenticated} 
              onTabChange={setActiveTab} 
            />
          </TabsContent>

          <TabsContent value="jobs" className="space-y-6">
            <JobManagement onBack={() => setActiveTab("dashboard")} />
          </TabsContent>

          <TabsContent value="customers" className="space-y-6">
            <CustomerManagement onBack={() => setActiveTab("dashboard")} />
          </TabsContent>

          <TabsContent value="financials" className="space-y-4 sm:space-y-6">
            <div className="space-y-4 sm:space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
                <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight">Financial Details</h2>
                <Button variant="outline" onClick={() => setActiveTab("dashboard")} className="w-full sm:w-auto">
                  Back to Dashboard
                </Button>
              </div>

              {/* Revenue Breakdown */}
              <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">
                      ${financialsLoading ? "..." : (financials as any)?.revenue?.toLocaleString() || 0}
                    </div>
                    <p className="text-xs text-muted-foreground">Current month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">
                      ${financialsLoading ? "..." : (financials as any)?.expenses?.toLocaleString() || 0}
                    </div>
                    <p className="text-xs text-muted-foreground">Current month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-blue-600">
                      ${financialsLoading ? "..." : (financials as any)?.profit?.toLocaleString() || 0}
                    </div>
                    <p className="text-xs text-muted-foreground">Revenue - Expenses</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Profit Margin</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {financialsLoading ? "..." : 
                        (financials as any)?.revenue > 0 ? 
                          Math.round(((financials as any)?.profit / (financials as any)?.revenue) * 100) + "%" 
                          : "0%"
                      }
                    </div>
                    <p className="text-xs text-muted-foreground">Profit / Revenue</p>
                  </CardContent>
                </Card>
              </div>

              {/* Revenue Sources */}
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Breakdown by Job Status</CardTitle>
                  <p className="text-sm text-muted-foreground">Detailed view of where your revenue comes from</p>
                </CardHeader>
                <CardContent>
                  {recentJobs && (recentJobs as any[]).length > 0 ? (
                    <div className="space-y-4">
                      {(recentJobs as any[]).map((job: any) => (
                        <div key={job.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <Badge className={getStatusColor(job.status)}>
                              {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                            </Badge>
                            <div>
                              <h4 className="font-medium">{job.title}</h4>
                              <div className="flex items-center text-sm text-muted-foreground space-x-4">
                                <span className="flex items-center space-x-1">
                                  <MapPin className="h-3 w-3" />
                                  <span>{job.originCity}, {job.originState}</span>
                                </span>
                                <span>→</span>
                                <span className="flex items-center space-x-1">
                                  <MapPin className="h-3 w-3" />
                                  <span>{job.destinationCity}, {job.destinationState}</span>
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-green-600">
                              ${Number(job.totalEstimate || 0).toLocaleString()}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(job.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <DollarSign className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No financial data available yet.</p>
                      <Button 
                        className="mt-4" 
                        onClick={() => setActiveTab("jobs")}
                      >
                        Create First Job
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="exports" className="space-y-6">
            <ExportManager />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}