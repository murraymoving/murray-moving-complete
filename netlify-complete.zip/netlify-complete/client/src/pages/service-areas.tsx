import { Helmet } from "react-helmet-async";
import ServiceAreaMap from "@/components/service-area-map";
import { Card } from "@/components/ui/card";
import { MapPin, Clock, Phone } from "lucide-react";

const serviceAreas = [
  {
    county: "Mercer County",
    cities: [
      "Chesterfield (Headquarters)",
      "Trenton",
      "Princeton", 
      "Hamilton Township",
      "Robbinsville",
      "East Windsor",
      "Hightstown",
      "Hopewell",
      "Lawrence Township",
      "West Windsor"
    ]
  },
  {
    county: "Burlington County", 
    cities: [
      "Bordentown",
      "Florence",
      "Burlington",
      "Mount Holly",
      "Moorestown",
      "Cinnaminson",
      "Delran",
      "Riverside"
    ]
  },
  {
    county: "Middlesex County",
    cities: [
      "New Brunswick",
      "Plainsboro",
      "South Brunswick",
      "North Brunswick",
      "Cranbury",
      "Monroe Township"
    ]
  },
  {
    county: "Somerset County",
    cities: [
      "Franklin Township",
      "Montgomery",
      "Hillsborough",
      "Manville",
      "Somerville"
    ]
  }
];

export default function ServiceAreasPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Helmet>
        <title>Service Areas - Murray Moving Coverage Map | NJ Moving Services</title>
        <meta name="description" content="See Murray Moving's complete service area map. We serve Mercer, Burlington, Middlesex, and Somerset counties in New Jersey with professional moving services." />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Our Service Areas</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Murray Moving proudly serves Central New Jersey with professional moving services. 
            We cover a 100-mile radius from our Chesterfield headquarters.
          </p>
        </div>

        {/* Interactive Map */}
        <div className="mb-16">
          <ServiceAreaMap />
        </div>

        {/* Service Areas Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {serviceAreas.map((area, index) => (
            <Card key={index} className="p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <MapPin className="w-5 h-5 text-green-600 mr-2" />
                {area.county}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {area.cities.map((city, cityIndex) => (
                  <div 
                    key={cityIndex}
                    className={`text-gray-600 ${city.includes('Headquarters') ? 'font-semibold text-green-600' : ''}`}
                  >
                    • {city}
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>

        {/* Additional Service Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 text-center">
            <MapPin className="w-8 h-8 text-green-600 mx-auto mb-3" />
            <h4 className="font-semibold text-gray-900 mb-2">100-Mile Radius</h4>
            <p className="text-gray-600 text-sm">
              We serve all areas within 100 miles of our Chesterfield headquarters
            </p>
          </Card>
          
          <Card className="p-6 text-center">
            <Clock className="w-8 h-8 text-green-600 mx-auto mb-3" />
            <h4 className="font-semibold text-gray-900 mb-2">Same-Day Service</h4>
            <p className="text-gray-600 text-sm">
              Emergency and last-minute moves available in our core service areas
            </p>
          </Card>
          
          <Card className="p-6 text-center">
            <Phone className="w-8 h-8 text-green-600 mx-auto mb-3" />
            <h4 className="font-semibold text-gray-900 mb-2">Free Estimates</h4>
            <p className="text-gray-600 text-sm">
              Call (609) 724-4445 for a free quote anywhere in our service area
            </p>
          </Card>
        </div>

        {/* Outside Service Area Notice */}
        <Card className="mt-12 p-6 bg-blue-50 border-blue-200">
          <h4 className="font-semibold text-blue-900 mb-2">Outside Our Service Area?</h4>
          <p className="text-blue-800">
            Don't see your location listed? We may still be able to help! Contact us at{' '}
            <a href="tel:+16097244445" className="font-semibold underline">
              (609) 724-4445
            </a>{' '}
            to discuss long-distance moves or special service arrangements.
          </p>
        </Card>
      </div>
    </div>
  );
}